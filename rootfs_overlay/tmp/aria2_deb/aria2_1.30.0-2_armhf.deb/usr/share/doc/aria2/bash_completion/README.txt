Bash_completion for aria2c
==========================

Install
-------

Copy 'aria2c' to the directory where bash_completion searches
completion files.  For Debian and Ubuntu, copy 'aria2c' to
'/etc/bash_completion.d/' and run

. /etc/bash_completion
